{
  "simulate-until-year": 2003,
  "tracer-lifetime": 28.8811,
  "soil-thickness": 0.6,
  "soil-effective-volume": 0.97,
  "soil-density": 1.49,
  "cell-thickness": 0.01,
  "numerical-cfl": 0.5,
  "mix-from-depth": 0,
  "mix-to-depth": 0.3,
  "mix-interval": 1,
  "mix-inicial-year": 1954,
  "mix-final-year": 2003,
  "fallout": {
    "initial-year": 1954,
    "final-year": 1983,
    "mix-depth": 0.01,
    "curve": [50, 150, 170, 190, 320, 350, 100, 140, 530, 1220, 670, 290, 180, 70, 70, 40, 70, 70, 40, 20, 40, 20, 20, 30, 30, 10, 10, 20, 10, 10],
    "reference-inventory": 1570
  },
  "optimization": {
    "k-initial": 0.002,
    "k-final": 0.002,
    "e-initial": -0.02,
    "e-final": 0.02,
    "k-samples": 1,
    "e-samples": 100
  }
}
